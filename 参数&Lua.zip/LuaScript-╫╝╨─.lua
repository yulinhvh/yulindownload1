local screenX, screenY = draw.GetScreenSize()

local ref = gui.Reference("十字准星线")
local crosshairGroup = gui.Groupbox(ref, "十字准星线", 16, 16, 200, 200)

local enableCrosshairCheckbox = gui.Checkbox(crosshairGroup, "enableCrosshairCheckbox", "启用十字准星", false)
local crosshairLengthSlider = gui.Slider(crosshairGroup, "crosshairLengthSlider", "十字线长度", 150, 0, 300)
local crosshairWidthSlider = gui.Slider(crosshairGroup, "crosshairWidthSlider", "十字线宽度", 1.5, 0, 10, 0.1)
local crosshairColorPicker = gui.ColorPicker(crosshairGroup, "crosshairColorPicker", "十字线颜色", 0, 0, 139, 255)

local lastCheckboxState = false

local function drawCustomCrosshair()
    local isCheckboxChecked = enableCrosshairCheckbox:GetValue()

    if isCheckboxChecked ~= lastCheckboxState then
        lastCheckboxState = isCheckboxChecked
        if isCheckboxChecked then
            client.Command("crosshair 0", true)
        else
            client.Command("crosshair 1", true)
        end
    end

    if not isCheckboxChecked then
        return
    end

    local localPlayer = entities.GetLocalPlayer()
    if localPlayer == nil or not localPlayer:IsAlive() then
        return
    end

    local crosshairLength = crosshairLengthSlider:GetValue()
    local crosshairWidth = crosshairWidthSlider:GetValue()

    local r, g, b, a = crosshairColorPicker:GetValue()

    local startX = screenX / 2 - crosshairLength / 2
    local startY = screenY / 2 - crosshairWidth / 2
    local endX = screenX / 2 + crosshairLength / 2
    local endY = screenY / 2 + crosshairWidth / 2

    draw.Color(r, g, b, a)
    draw.FilledRect(startX, startY, endX, endY)

    startX = screenX / 2 - crosshairWidth / 2
    startY = screenY / 2 - crosshairLength / 2
    endX = screenX / 2 + crosshairWidth / 2
    endY = screenY / 2 + crosshairLength / 2

    draw.FilledRect(startX, startY, endX, endY)
end

callbacks.Register("Draw", drawCustomCrosshair)
