LoadScript('LuaScript-静默修复.lua');
LoadScript('LuaScript-自动拆弹.lua');
LoadScript('LuaScript-准心.lua');
LoadScript('LuaScript-机器人.lua');
LoadScript('LuaScript-水印.lua');
LoadScript('LuaScript-中文汉化.lua');
