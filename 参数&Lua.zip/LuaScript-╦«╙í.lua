local wallpaper = nil

callbacks.Register("Draw", function()
    if not wallpaper and entities.GetLocalPlayer() then
    -- 如果要改图片修改后面那段wallpaper.png
        wallpaper = draw.CreateTexture(common.DecodePNG(file.Read("wallpaper/wallpaper.png")))
    end

    local screenX, screenY = draw.GetScreenSize()
    if wallpaper and entities.GetLocalPlayer() and entities.GetLocalPlayer():IsAlive() then
        draw.SetTexture(wallpaper)
        draw.FilledRect(0, 0, screenX, screenY)
    end
end)
